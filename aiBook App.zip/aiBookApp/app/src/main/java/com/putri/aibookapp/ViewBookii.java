package com.putri.aibookapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.joanzapata.pdfview.PDFView;

public class ViewBookii extends AppCompatActivity {

    private PDFView ViewBookii;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_bookii);
        ViewBookii = findViewById(R.id.ViewBookii);

        ViewBookii.fromAsset("buku_insecurity.pdf")
                .swipeVertical(true)
                .load();
    }
}