package com.putri.aibookapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.joanzapata.pdfview.PDFView;

public class ViewBookwe extends AppCompatActivity {

    private PDFView ViewBookwe;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_bookwe);
        ViewBookwe = findViewById(R.id.ViewBookwe);

        ViewBookwe.fromAsset("buku_tere_liye.pdf")
                .swipeVertical(true)
                .load();
    }
}