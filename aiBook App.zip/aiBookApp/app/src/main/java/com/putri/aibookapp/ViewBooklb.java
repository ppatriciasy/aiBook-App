package com.putri.aibookapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.joanzapata.pdfview.PDFView;

public class ViewBooklb extends AppCompatActivity {

    private PDFView ViewBooklb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_booklb);
        ViewBooklb = findViewById(R.id.ViewBooklb);

        ViewBooklb.fromAsset("buku_laut_bercerita.pdf")
                .swipeVertical(true)
                .load();
    }
}