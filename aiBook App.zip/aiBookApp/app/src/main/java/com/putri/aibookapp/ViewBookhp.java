package com.putri.aibookapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.joanzapata.pdfview.PDFView;

public class ViewBookhp extends AppCompatActivity {

    private PDFView ViewBookhp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_bookhp);
        ViewBookhp = findViewById(R.id.ViewBookhp);

        ViewBookhp.fromAsset("buku_harry_potter.pdf")
                .swipeVertical(true)
                .load();
    }
}